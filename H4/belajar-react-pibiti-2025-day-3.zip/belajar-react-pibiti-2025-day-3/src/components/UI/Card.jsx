function Card(props) {
  return <div className="w-full max-w-7xl mx-auto">{props.children}</div>;
}

export default Card;
