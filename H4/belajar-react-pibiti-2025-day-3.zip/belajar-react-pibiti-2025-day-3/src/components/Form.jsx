// import React, { useContext } from "react";
// import { TodoContext } from "../context/todoContext"; //Import context untuk todo

// function Form({ input, setInput }) {
//   const { handleAddTodo } = useContext(TodoContext);

//   return (
//     <form className="todo-form" onSubmit={handleAddTodo}>
//       <input
//         type="text"
//         className="todo-input"
//         value={input}
//         onChange={(e) => setInput(e.target.value)}
//         placeholder="Tambahkan Kegiatan Baru.."
//       />
//       <button type="submit" className="todo-button">
//         Tambah
//       </button>
//     </form>
//   );
// }

// export default Form;
